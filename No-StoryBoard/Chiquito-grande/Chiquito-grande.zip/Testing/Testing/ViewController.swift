//
//  ViewController.swift
//  Testing
//
//  Created by Germán Santos Jaimes on 5/5/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var flag = 0
    
    let mv : UIView = {
        let v = UIView()
        v.backgroundColor = UIColor.red
        v.translatesAutoresizingMaskIntoConstraints = false
        
        return v
    }()
    
    let bt: UIButton = {
        let b = UIButton(type: .system)
        b.setTitle("click please", for: .normal)
        b.addTarget(self, action: #selector(click), for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        
        return b
    }()
    
    // paso 1
    // en lugar de dejarle el constraint a una funcion, se lo dejamos a una variable, perdón a un objeto, so, aqui el objeto que modificará el tamaño.
    
    var mvHeightAnchor: NSLayoutConstraint?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(mv)
        view.addSubview(bt)
        view.backgroundColor = UIColor.white
        
        mv.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        mv.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        mv.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        // paso 2
        // entonces despues de declarado el objeto, le damos el resultado del constraint y lo activamos.
        mvHeightAnchor = mv.heightAnchor.constraint(equalToConstant: 200)
        mvHeightAnchor?.isActive = true
       
       
        bt.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        bt.topAnchor.constraint(equalTo: mv.bottomAnchor).isActive = true
        bt.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        bt.heightAnchor.constraint(equalToConstant: 30).isActive = true
    }
    
    @objc func click(){
        //paso 3, como el objeto es dueño del constraint, entonces lo modificamos a gusto.
        
        if flag == 0{
            mvHeightAnchor?.constant = 500
            flag = 1
        }else{
            mvHeightAnchor?.constant = 200
            flag = 0
        }
        
    }


}

