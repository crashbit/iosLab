//
//  ViewController.swift
//  ex2
//
//  Created by Germán Santos Jaimes on 7/19/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit
import Vision
import ImageIO

class UDGViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    let texto : UILabel = {
        var lb = UILabel()
        lb.text = "Hola CU Valles"
        lb.font = UIFont(name: "Arial", size: 40)
        lb.translatesAutoresizingMaskIntoConstraints = false
        return lb
    }()
    
    let boton : UIButton = {
        var bt = UIButton(type: .system)
        
        bt.setTitle("Detecta rostros", for: .normal)

        bt.translatesAutoresizingMaskIntoConstraints = false
        bt.addTarget(self, action: #selector(clicked), for: .touchUpInside)
        return bt
    }()
    
    let imagen : UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(named: "desconocido")
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.layer.cornerRadius = 50.0
        iv.clipsToBounds = true
        
        return iv
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(pickImage))
        
        view.addSubview(texto)
        view.addSubview(boton)
        view.addSubview(imagen)
        
        texto.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        texto.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        boton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        boton.topAnchor.constraint(equalTo: texto.bottomAnchor, constant: 5).isActive = true
       
        imagen.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        imagen.bottomAnchor.constraint(equalTo: texto.topAnchor, constant: -20).isActive = true
        
        imagen.heightAnchor.constraint(equalToConstant: 200).isActive = true
        imagen.widthAnchor.constraint(equalToConstant: 200).isActive = true
    }

    @objc func pickImage(){
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true, completion: nil)
    }

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let imagenSeleccionada = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            self.imagen.image = imagenSeleccionada
            dismiss(animated: true, completion: nil)
        }
    }
    
    @objc func clicked(){
        
        let leNetPlaces = GoogLeNetPlaces()
        var test: VNRequest!
        
        if let model = try? VNCoreMLModel(for: leNetPlaces.model){
            let mlRequest = VNCoreMLRequest(model: model, completionHandler: handlePlaces)
            test  = mlRequest
        }
        
        
        
        // Paso 1
        guard let cgImage = imagen.image?.cgImage else {
            return
        }
        // paso 2
        let orientation = CGImagePropertyOrientation(rawValue: UInt32(imagen.image!.imageOrientation.rawValue))
        
        // paso 3
        let faceRequest = VNDetectFaceRectanglesRequest(completionHandler: handleFaces)
        
        let handler = VNImageRequestHandler(cgImage: cgImage, orientation: orientation!)
    
        DispatchQueue.global(qos: .userInteractive).async{
            do{
                try handler.perform([faceRequest,test])
            }catch{
                print("Error al manejar Vision")
            }
        }
    }
    
    func handleFaces(request: VNRequest, error: Error?){
        guard let observations = request.results as? [VNFaceObservation] else {
            print("Resultado inesperado del faceRequest")
            return
        }
        
        DispatchQueue.main.async {
            self.handleFaces(observations: observations)
        }
    }
    
    func handleFaces(observations: [VNFaceObservation]){
        texto.text = "Hay \(observations.count) rostros"
        
        for face in observations{
            
            let box1 = face.boundingBox
            let box2 = imagen.bounds
            
            let w = box1.size.width *  box2.width
            let h = box1.size.height * box2.height
            
            let x = box1.origin.x * box2.width
            let y = abs((box1.origin.y * box2.height) - box2.height) - h
            
            let subView = UIView(frame: CGRect(x: x, y: y, width: w, height: h) )
            
            
            subView.layer.borderColor = UIColor.red.cgColor
            subView.layer.borderWidth = 2.0
            subView.tag = 5
            imagen.addSubview(subView)
            
        }
    }

    func handlePlaces(request: VNRequest, error: Error?){
        guard let observations = request.results as? [VNClassificationObservation] else {
            print("Resultado inesperado para VNCoreMLRequest")
            return
        }
        
        guard let bestResult = observations.first else{
            print("No hay clasificacion valida")
            return
        }
        
        DispatchQueue.main.async{
            print("\(bestResult.identifier) - \(bestResult.confidence)")

        }
    }
}







