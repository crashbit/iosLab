//
//  MostrarViewController.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class MostrarViewController: UIViewController {

    @IBOutlet weak var nombreLabel: UILabel!
    var nombre: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        nombreLabel.text = nombre!
    }
}
