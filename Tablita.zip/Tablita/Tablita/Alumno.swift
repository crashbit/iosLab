//
//  Alumno.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

struct Alumno{
    var nombre: String
    var apellidos: String
    var id: Int
    var aprobado: Bool
}
