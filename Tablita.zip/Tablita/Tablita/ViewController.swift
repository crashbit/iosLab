//
//  ViewController.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var alumnos: [Alumno] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row].nombre
        if alumnos[indexPath.row].aprobado{
            cell.accessoryType = .checkmark
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let alert = UIAlertController(title: "Titulo", message: "este es el mensaje", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        
        present(alert, animated: true, completion: nil)
        
        
        
        let cell = tableView.cellForRow(at: indexPath)
        
        if alumnos[indexPath.row].aprobado{
            cell?.accessoryType = .none
            alumnos[indexPath.row].aprobado = false
        }else{
            cell?.accessoryType = .checkmark
            alumnos[indexPath.row].aprobado = true
        }
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        let alumno1 = Alumno(nombre: "Pedro", apellidos: "Juarez", id: 1, aprobado: false)
        let alumno2 = Alumno(nombre: "Juan", apellidos: "Sanchez", id: 2, aprobado: false)
        let alumno3 = Alumno(nombre: "Roberto", apellidos: "Peres", id: 3, aprobado: true)
        let alumno4 = Alumno(nombre: "Lola", apellidos: "Mendez", id: 4, aprobado: true)
        
        alumnos.append(alumno1)
        alumnos.append(alumno2)
        alumnos.append(alumno3)
        alumnos.append(alumno4)
        
        
    }


}

