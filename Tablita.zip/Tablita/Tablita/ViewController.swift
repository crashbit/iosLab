//
//  ViewController.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var alumnos: [Alumno] = []
    fileprivate var selectedRow : Int?
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row].nombre
        if alumnos[indexPath.row].aprobado{
            cell.accessoryType = .checkmark
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let okClosure = { (action: UIAlertAction) -> Void in
            let cell = tableView.cellForRow(at: indexPath)
            
            if self.alumnos[indexPath.row].aprobado{
                cell?.accessoryType = .none
                self.alumnos[indexPath.row].aprobado = false
            }else{
                cell?.accessoryType = .checkmark
                self.alumnos[indexPath.row].aprobado = true
            }
            self.selectedRow = indexPath.row
            self.performSegue(withIdentifier: "muestra", sender: self)
        }
        
        let alert = UIAlertController(title: "Titulo", message: "este es el mensaje", preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "OK", style: .default, handler: okClosure)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        
        
        present(alert, animated: true, completion: nil)

    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true

    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            alumnos.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } 
    }
    
    
    @IBAction func insertAlumno(_ sender: UIBarButtonItem) {
        
        let captura = CapturaViewController()
        
        present(captura,animated: true, completion: nil )
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "muestra"{
            if let mostrar = segue.destination as? MostrarViewController{
            mostrar.nombre = String(selectedRow!)
            }
        }else{
            let capturar = segue.destination as! CapturaViewController
            capturar.alumnos = alumnos
        }
        
    }
    
}

