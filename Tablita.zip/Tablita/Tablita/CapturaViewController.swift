//
//  CapturaViewController.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class CapturaViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    var alumnos: [Alumno]!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    @IBAction func agregar(_ sender: UIButton) {
        
        print("Click")
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let main = segue.destination as! ViewController
        let alumno = Alumno(nombre: caja.text!, apellidos: "chiquito", id: 5, aprobado: true)
        alumnos.append(alumno)
        main.alumnos = alumnos
        
        print("A enviar info")
    }
    
    
}
