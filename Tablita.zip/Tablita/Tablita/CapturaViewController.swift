//
//  CapturaViewController.swift
//  Tablita
//
//  Created by Germán Santos Jaimes on 7/24/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class CapturaViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func regrsar(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    
}
