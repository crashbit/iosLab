//
//  ViewController.swift
//  Segue
//
//  Created by Germán Santos Jaimes on 7/25/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
        if segue.identifier == "next"{
            let nextView = segue.destination as! SecondViewController
            nextView.cadena = "Alumnos trabajando"
        }
    }
    
    @IBAction func unwindToViewController(segue: UIStoryboardSegue){
    
    }

}





