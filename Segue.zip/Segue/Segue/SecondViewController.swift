//
//  SecondViewController.swift
//  Segue
//
//  Created by Germán Santos Jaimes on 7/25/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var cadena: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print(cadena!)
    }

   

}
