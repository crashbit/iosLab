//
//  ViewController.swift
//  Persistencia
//
//  Created by Germán Santos Jaimes on 7/26/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var caja: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let recuperaInfo = UserDefaults.standard.string(forKey: "informacion")
        
        if recuperaInfo != nil{
            caja.text = recuperaInfo
        }else{
            caja.text = "no hay información"
        }
    }
    
    
    
    @IBAction func guardarDato(_ sender: UIButton) {
        
        
        
        let info = caja.text
        
        UserDefaults.standard.set(info, forKey: "informacion")
        
    }
    
    
    
    @IBAction func unwindViewController(segue: UIStoryboardSegue){
        
    }
    
}

