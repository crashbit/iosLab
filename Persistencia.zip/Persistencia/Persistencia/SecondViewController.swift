//
//  SecondViewController.swift
//  Persistencia
//
//  Created by Germán Santos Jaimes on 7/26/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        let recuperaInfo = UserDefaults.standard.string(forKey: "informacion")
        
        if recuperaInfo != nil{
            label.text = recuperaInfo
        }else{
            label.text = "no hay información"
        }
        
    }

    
}
