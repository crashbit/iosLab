//
//  Datos.swift
//  Archivos
//
//  Created by Germán Santos Jaimes on 7/27/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Datos: Codable{
    var info: String
}
