//
//  ViewController.swift
//  Archivos
//
//  Created by Germán Santos Jaimes on 7/27/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
     
        let dato = Datos(info: "hola mundo")

        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        let archiveURL = documentsDirectory.appendingPathComponent("datos_text").appendingPathExtension("plist")
        
        let propertyListEncoder = PropertyListEncoder()
        
        let encodeDato = try? propertyListEncoder.encode(dato)
        
        try? encodeDato?.write(to: archiveURL, options: .noFileProtection)
        
        // Retrieve
        
        let propertyListDecoder = PropertyListDecoder()
        if let retrieveDato = try? Data(contentsOf: archiveURL), let decodeDato = try? propertyListDecoder.decode(Datos.self, from: retrieveDato){
            print(decodeDato.info)
        }
        
        
    }

    

}

