//
//  ViewController.swift
//  image
//
//  Created by Germán Santos Jaimes on 7/27/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imagen: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let url = URL(string: "https://apod.nasa.gov/apod/image/1807/MarsOpp2panelSTSCI_1047.jpg")
        let task = URLSession.shared.dataTask(with: url!){ (data, response, error) in
            
            if let data = data{
                self.imagen.image = UIImage(data: data)
            }
        }
        
        task.resume()
        
        
        
    }

    
}

