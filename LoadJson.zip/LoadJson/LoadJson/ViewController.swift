//
//  ViewController.swift
//  LoadJson
//
//  Created by Germán Santos Jaimes on 10/1/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var listaPersonas : [Person] = []
    
    struct Resultado : Codable{
        var total : String
        var person: [Person]
    }
    
    struct Person : Codable{
        var first_name : String
        var last_name : String
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        listaPersonas = cargaArchivo()
        for persona in listaPersonas{
            print(persona.first_name, persona.last_name)
        }
    }
    
    
    func cargaArchivo() -> [Person]{
        let jsondecoder = JSONDecoder()
        var listaTemp = [Person]()
        if let path = Bundle.main.path(forResource: "names", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let results = try jsondecoder.decode(Resultado.self, from: data)
                
                results.person.forEach { (person) in
                    listaTemp.append(Person(first_name: person.first_name, last_name: person.last_name))
                }
            } catch {
                print(error)
            }
        }
        
        return listaTemp
    }


}

