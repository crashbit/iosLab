//
//  ContactoTableViewController.swift
//  Table2
//
//  Created by Germán Santos Jaimes on 7/18/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ContactoTableViewController: UITableViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        //self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    //self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        let celdaNueva = UINib(nibName: "PerritoTableViewCell", bundle: nil)
        tableView.register(celdaNueva, forCellReuseIdentifier: "celdaNueva")
        navigationController?.navigationBar.prefersLargeTitles = true
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 30
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celdaNueva", for: indexPath) as! PerritoTableViewCell
        
        cell.titulo.text = " \(indexPath.row)"
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        let cancelClosure = { (action: UIAlertAction) -> Void in
//            print("Cancelo, cancelo")
//        }
//
//        let optionMenu = UIAlertController(title: "Menu", message: "Desea adoptar al perrito?", preferredStyle: .alert)
//
//        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: cancelClosure)
//
//        let okAction = UIAlertAction(title: "Aceptar", style: .default, handler: { (action) in
//
//            let cell = tableView.cellForRow(at: indexPath)
//            cell?.accessoryType = .checkmark
//        })
//
//        optionMenu.addAction(cancelAction)
//        optionMenu.addAction(okAction)
//
//        present(optionMenu, animated: true, completion: nil)
//
//        tableView.deselectRow(at: indexPath, animated: false)
        
//        let destination = DetailViewController()
//        destination.cadena = "Hooolaaa"
//        navigationController?.pushViewController(destination, animated: true)
    performSegue(withIdentifier: "detailSegue", sender: nil)
        
    }
 
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let deleteAction = UIContextualAction(style: .destructive, title: "Borrar") { (action, sourceView, completionHandler) in
            
            completionHandler(true)
        }
        
        let shareAction = UIContextualAction(style: .normal, title: "Compartir") { (action, sourceView, completionHandler) in
            let message = "Adoptando perrito"
            
            let activityController = UIActivityViewController(activityItems: [message], applicationActivities: nil)
            
            self.present(activityController, animated: true, completion: nil)
            
            completionHandler(true)
        }
        
        shareAction.backgroundColor = UIColor.cyan
        shareAction.image = UIImage(named: "perrito")
        
        let swipeConfiguration = UISwipeActionsConfiguration(actions: [deleteAction, shareAction])
        
        return swipeConfiguration
        
    }
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    
    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("ejecutando segue")
        if segue.identifier == "detailSegue"{
            let destinationController = segue.destination as! DetailViewController
            
            destinationController.cadena = "pasando"
            
        }
    }
    

}
