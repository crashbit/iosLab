//
//  PerritoTableViewCell.swift
//  Table2
//
//  Created by Germán Santos Jaimes on 7/18/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class PerritoTableViewCell: UITableViewCell {

    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var imagen: UIImageView!{
        didSet {
            imagen.layer.cornerRadius = 50.0
            imagen.clipsToBounds = true
        }
    }
    @IBOutlet weak var titulo: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)        
        
    }
    
}
